package com.solidlucho.bitcoinwidget
import  com.solidlucho.bitcoinwidget.Repository

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

class MainViewModel(private val repository: Repository):ViewModel() {

    fun DameValor(){
        viewModelScope.launch
    }






}