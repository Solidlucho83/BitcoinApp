package com.solidlucho.bitcoinwidget

import retrofit2.Retrofit
import com.solidlucho.bitcoinwidget.Cripto


class Repository {
    suspend fun getUsd():Cripto {
       return RetrofitInstance.api.getUsd()

    }
}