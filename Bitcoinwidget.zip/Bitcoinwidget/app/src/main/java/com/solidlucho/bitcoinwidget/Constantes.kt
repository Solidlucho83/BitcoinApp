package com.solidlucho.bitcoinwidget

class Constantes {

    companion object{
        const val  BASE_URL = "https://api.coingecko.com/api/v3/"
    }
}