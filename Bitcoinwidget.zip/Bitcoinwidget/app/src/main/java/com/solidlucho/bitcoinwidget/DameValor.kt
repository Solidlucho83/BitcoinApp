package com.solidlucho.bitcoinwidget

import retrofit2.http.GET

interface DameValor {

    @GET("simple/price?ids=bitcoin&vs_currencies=usd")
    suspend fun getUsd():Cripto

}