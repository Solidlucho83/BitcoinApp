package com.solidlucho.bitcoinwidget

data class Cripto(
    var bitcoin: String,
    var usd: Int
)